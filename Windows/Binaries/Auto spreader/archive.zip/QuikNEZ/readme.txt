The updater and QuikN'EZ executable should be kept in the same directory for best results, although it's not necessary. You can merge your existing torrent config folder with the one included in this release if you wish.

Both the updater and QuikN'EZ Spreader executable check your HWID. If for some reason you lose your QuikN'EZ executable you can use the updater to recover it.

THE QUIKN'EZ APPLICATION WILL NOTIFY YOU THAT THERE IS A NEW UPDATE AVAILABLE. This means you don't have to keep checking the updater all the time.

Please send any bugs or questions to support@pixelatedfocus.com