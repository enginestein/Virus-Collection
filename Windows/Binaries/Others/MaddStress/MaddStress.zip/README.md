
M A D D S T R E S S
                                                                                                                                                                                                                                                                              
> READ PLEASE BEFORE USE

- MaddStress is a denial-of-service (DDoS) attack refers to attempts to overload a network or 
server with requests, rendering them unavailable to users.


> DONATE

- Feel free to donate if you found it useful, I would like to add improvements.
Please help to donate to update more version.

- BTC : 38JYmWtXezJj6xUMorcXZvn6kphmAZxZ66


> VIRUS CHECK

- Last VirusTotal Checked : https://www.virustotal.com/gui/file/4f562dca39c16d2864b404e8adae923aac9714ca475dc7b9b0096cdadfc82231/detection


> REQUIRMENTS

- PLEASE INSTALL THE FONT BEFORE USE IT !


> MESSAGE

- I created this tool for system administrators and game developers to test their servers. Use at your own risk.

> CONTACT

- DrWeabo@gmail.com
