Some people had problem with that normal version.
I`ve published this patch to fix that.
If that don`t work, try set Compability to Windows XP.
Good luck!

~KarelDev